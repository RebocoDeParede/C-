#include <iostream> // Biblioteca para entrada e saída de dados em C++
#include <stack>    // Biblioteca para utilizar fila em C++

// Função para adicionar nova tarefa à lista
void emprestimosLivros(std::stack<std::string> &lista, std::string tarefa)
{
    lista.push(tarefa); // Adiciona a nova tarefa à fila
}

// Função para marcar tarefa como concluída
void marcarConcluida(std::stack<std::string> &lista)
{
    if (!lista.empty())
    {                                                                    // Verifica se a lista não está vazia
        std::cout << "Livros devolvidos: " << lista.top() << std::endl; // Exibe a tarefa a ser marcada como concluída
        lista.pop();                                                     // Remove a tarefa concluída da fila
    }
    else
    {
        std::cout <<  "lista de emprestimos!\n"; // Exibe mensagem se a lista estiver vazia
    }
}

// Função para exibir a lista atual de afazeres
void exibirLista(std::stack<std::string> lista)
{
    std::cout << "Lista de emprestimos:\n";
    while (!lista.empty())
    {
        std::cout << lista.top() << std::endl; // Exibe cada tarefa da lista
        lista.pop();                             // Remove a tarefa exibida da fila
    }
}

int main()
{
    std::stack<std::string> listaAfazeres; // Fila para armazenar as tarefas

    // Adiciona algumas tarefas à lista inicialmente
    emprestimosLivros(listaAfazeres, "HAry poeta");
    emprestimosLivros(listaAfazeres, "Antiotario");
    emprestimosLivros(listaAfazeres, "GTA rp,  o guia completo");

    // Exibe a lista de afazeres inicial
    exibirLista(listaAfazeres);

    // Marca algumas tarefas como concluídas
    marcarConcluida(listaAfazeres);
    marcarConcluida(listaAfazeres);

    // Exibe a lista de afazeres após as conclusões
    exibirLista(listaAfazeres);

    return 0;
}