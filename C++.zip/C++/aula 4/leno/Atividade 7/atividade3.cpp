#include <iostream>
#include <vector>
#include <string>

using namespace std;


struct Contato {
    string nome;
    string telefone;
};


void adicionarContato(vector<Contato>& agenda, const string& nome, const string& telefone) {
    Contato novoContato = {nome, telefone};
    agenda.push_back(novoContato);
    cout << "Contato adicionado com sucesso!" << endl;
}


void buscarContato(const vector<Contato>& agenda, const string& nome) {
    bool encontrado = false;
    for (const auto& contato : agenda) {
        if (contato.nome == nome) {
            cout << "Nome: " << contato.nome << ", Telefone: " << contato.telefone << endl;
            encontrado = true;
        }
    }
    if (!encontrado) {
        cout << "Contato nao encontrado." << endl;
    }
}


void exibirContatos(const vector<Contato>& agenda) {
    if (agenda.empty()) {
        cout << "Agenda vazia. Nenhum contato para exibir." << endl;
    } else {
        cout << "Lista de Contatos:" << endl;
        for (const auto& contato : agenda) {
            cout << "Nome: " << contato.nome << ", Telefone: " << contato.telefone << endl;
        }
    }
}

int main() {
    vector<Contato> agenda;
    int opcao;
    
    do {
        cout << "\nMenu:" << endl;
        cout << "1. Adicionar novo contato" << endl;
        cout << "2. Buscar contato pelo nome" << endl;
        cout << "3. Exibir lista de contatos" << endl;
        cout << "4. Sair" << endl;
        cout << "Escolha uma opcao: ";
        cin >> opcao;
        
        switch (opcao) {
            case 1: {
                string nome, telefone;
                cout << "Digite o nome do contato: ";
                cin.ignore();
                getline(cin, nome);
                cout << "Digite o telefone do contato: ";
                getline(cin, telefone);
                adicionarContato(agenda, nome, telefone);
                break;
            }
            case 2: {
                string nomeBusca;
                cout << "Digite o nome do contato que deseja buscar: ";
                cin.ignore();
                getline(cin, nomeBusca);
                buscarContato(agenda, nomeBusca);
                break;
            }
            case 3:
                exibirContatos(agenda);
                break;
            case 4:
                cout << "Saindo..." << endl;
                break;
            default:
                cout << "Opcao invalida. Tente novamente." << endl;
                break;
        }
    } while (opcao != 4);

    return 0;
}
