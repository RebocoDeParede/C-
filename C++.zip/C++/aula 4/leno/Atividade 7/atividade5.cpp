#include <iostream>
#include <stack>
#include <string>

using namespace std;

struct Livro {
    string titulo;
    string autor;
    int ano;
};


void exibirLivro(const Livro& livro) {
    cout << "Título: " << livro.titulo << endl;
    cout << "Autor: " << livro.autor << endl;
    cout << "Ano: " << livro.ano << endl;
    cout << "-----------------------------" << endl;
}

int main() {
    stack<Livro> pilhaLivrosEmprestados;

    Livro livro1 = {"Harry Poter", "Chikago Claudino", 1605};
    Livro livro2 = {"Mob Dick", "Lenon Oliveira", 1967};
    Livro livro3 = {"Diario de um Zumbi dos Palmares", "Paulo Henrique", 1813};

    pilhaLivrosEmprestados.push(livro1);
    pilhaLivrosEmprestados.push(livro2);
    pilhaLivrosEmprestados.push(livro3);


    cout << "Livros emprestados atualmente:" << endl;
    stack<Livro> pilhaTemporaria = pilhaLivrosEmprestados;

    while (!pilhaTemporaria.empty()) {
        Livro topo = pilhaTemporaria.top();
        exibirLivro(topo);
        pilhaTemporaria.pop();
    }

    cout << "Devolvendo o livro mais recentemente emprestado:" << endl;
    if (!pilhaLivrosEmprestados.empty()) {
        Livro livroDevolvido = pilhaLivrosEmprestados.top();
        exibirLivro(livroDevolvido);
        pilhaLivrosEmprestados.pop();
    } else {
        cout << "Não há livros emprestados para devolver." << endl;
    }

    cout << "Livros emprestados após devolução:" << endl;
    pilhaTemporaria = pilhaLivrosEmprestados;
    while (!pilhaTemporaria.empty()) {
        Livro topo = pilhaTemporaria.top();
        exibirLivro(topo);
        pilhaTemporaria.pop();
    }

    return 0;
}