
#include <iostream> //biblioteca 

using namespace std; //usado para ter que não usar o STD

int main () {
	int folhalindaprakrl; //inteiros
    folhalindaprakrl = true;
    do{
        cout<<"Lenon   ";
    
}
while (folhalindaprakrl);
{
}
return 0;
}
