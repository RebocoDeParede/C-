#include <iostream>
int main(){
    std::cout<<"eu te odeio Maria Joaquina!";
    return 0;
}