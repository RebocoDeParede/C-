#include <iostream>
using namespace std;
int main (){
    char operador;
    double num1, num2, resultado;
    std::cout <<"Digite um operador(+,-,*,/): ";
    std::cin >> operador;
    
    std::cout << "Digite dois operandos: ";
    std::cin >> num1 >> num2;
    
    switch(operador) {
        case '+':
         resultado = num1 + num2;
         break;
        case '-':
         resultado = num1 - num2;
         break;
        case '*':
         resultado = num1 * num2;
         break;
        case '/':
        if (num2 != 0)
         resultado = num1 / num2;
        else{
            std::cout << "Erro! Divisão por zero nãe é permitida";
            return 1;
        }
        break;
    default:
       std::cout << "Operador invalido!";
       return 1;
    }
    
    std::cout << "Resultado: " << resultado << std::endl;
    
    return 0;
}