#include <iostream>
using namespace std;
int main (){
    char operacao;
    float num1, num2, resultado;
    
    cout<<"Digite o primeiro número: ";
    cin>>num1;
    
    cout<<"Digite a operacao (+, -, *, /): ";
    cin>>operacao;
    
    cout<<"Digite o seguno número: ";
    cin>>num2;
    
    if (operacao== '+'){
        resultado = num1 + num2;
    } else if (operacao == '-'){
        resultado = num1 - num2;
    } else if (operacao == '*'){
        resultado = num1 * num2;
    } else if (operacao == '/'){
        if (num2 !=0) {
            resultado = num1 / num2;
        } else { 
            cout<<"Operação inválida";
            return 0;
        
    }
    } else { 
        cout<<"Operação inválida";
     return 0;
}
        cout << "Resultado: "<< resultado<<endl;

                return 0;

}