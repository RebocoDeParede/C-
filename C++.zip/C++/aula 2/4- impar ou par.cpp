#include <iostream>

int main (){
    int numero;
    std::cout<<"Digite um número: ";
    std::cin>>numero;
    
    if (numero%2==0){
        std::cout<<"O seu número é par"<<std::endl;
    } else { 
        std::cout<<"O seu número é impar"<<std::endl;
    }
return 0;
}