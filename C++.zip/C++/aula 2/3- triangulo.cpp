#include <iostream>
using namespace std;
int main (){
    char operacao;
    float lado1, lado2, lado3;
    
    cout<<"Digite o primeiro número: ";
    cin>>lado1;
    
    cout<<"Digite o seguno número: ";
    cin>>lado2;
    
    cout<<"Digite o terceiro número: ";
    cin>>lado3;
    
    if (lado1+lado2>lado3&&lado1+lado3>lado2&&lado2+lado3>lado1){
    cout<<"é possível de fazer um triângulo";
    } else {
        cout<<"não é possível de se fazer um triângulo";
    }
    return 0;
}