#include <iostream>
#include <cstdlib>
using namespace std;

int main (){
    int numeroSeceto=rand()%100+1;
    int tentativas=10;
    int palpite;
    
    do{
        cout<<"tentativas restantes: "<<tentativas<<"\n""Digite um número: ";
        cin>>palpite;
        if (palpite<numeroSeceto){
            cout<<"O número é mais alto!"<<endl;
        } else if 
            (palpite>numeroSeceto){
             cout<<"O número é menor!"<<endl;
            }
        tentativas--;
        
    } while (palpite!=numeroSeceto&&tentativas>0);
    if (palpite==numeroSeceto){
        cout<<"Parabéns! Você acertou o número faltando "<<tentativas<<"tentativas"<<endl;
    } else { 
        cout<<"Você não conseguiu adivinhar o número. O número certo era "<<numeroSeceto<<endl;
    }
    return 0;
}