#include <iostream>

using namespace std;

int main (void) {
    cout <<"Lenon por favor me ajuda eu sou burro :("<< endl; 
    
    return 0;
    
}