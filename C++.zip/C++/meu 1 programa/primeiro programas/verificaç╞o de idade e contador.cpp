#include <stdio.h>

int main ()
{
    int idade = 50; 
    
    if (idade>=50){
        printf ("voce é velho pra burro kkkkk");
    }
    else
    {
        printf("voce e novin, n gostei de voce :(");
    }
    
    int i = 0;
    for  (i = 1; i<=10; i++){
        printf ("%d\n", i);
    }
    return 0; 
}