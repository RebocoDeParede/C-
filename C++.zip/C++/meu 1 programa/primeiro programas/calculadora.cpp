#include <iostream> 

using namespace std;

int main ()

{
    int a, b, soma;
    cout << "digite o valor de a:";
    cin >> a ;
    b=2;
    soma = a + b;
    cout << soma << '\n';
    system ("pause");
}