#include <iostream>
#include <string>

using namespace std;

int main()
{
    string nomeDinossauro;
    string especie;


    cout << "Digite o nome do dinossauro: ";
    getline(cin, nomeDinossauro);


    if (nomeDinossauro == "Tyrannosaurus rex") {
        especie = "Tiracossáurideo";
    }
    else if (nomeDinossauro == "Triceratops") {
        especie = "Ceratopsídeo";
    }
    else if (nomeDinossauro == "Velociraptor") {
        especie = "Velociraptor";
    }
    else {
        especie = "Espécie não identificada";
    }


   cout << "A espécie do dinossauro " << nomeDinossauro << " e: "<< especie << endl;

   return 0;
}