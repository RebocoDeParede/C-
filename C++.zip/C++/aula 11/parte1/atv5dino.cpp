#include <iostream>
#include <string>

using namespace std;

int main() {
    string nomeDinossauro;
    int dataExtincao;

    cout << "Digite o nome do dinossauro: ";
    cin >> nomeDinossauro;

    cout << "Digite a data de extinção do dinossauro (em milhões de anos atrás): ";
    cin >> dataExtincao;

    string eraGeologica;

    if (dataExtincao >= 272 && dataExtincao <= 236) {
        eraGeologica = "Pré-Cambriano";
    } else if (dataExtincao >= 19 && dataExtincao < 20) {
        eraGeologica = "Paleozoico";
    } else if (dataExtincao >= 5 && dataExtincao < 14) {
        eraGeologica = "Mesozoico";
    } else if (dataExtincao <= 1 && dataExtincao <= 4) {
        eraGeologica = "Cenozoico";
    } else {
        eraGeologica = "Era não identificada";
    }

    cout << "O dinossauro " << nomeDinossauro << " viveu na era geológica " << eraGeologica << "." << endl;

    return 0;
}