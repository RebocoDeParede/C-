#include <iostream>
#include <string>
using namespace std;
int main(){
    
string nomeDinossauro;
int tamanhoFemur;
double tamanhofemur;

cout << "Entre com o nome do dinossauro: ";
cin >> nomeDinossauro;

cout << "Digite o tamanho do fêmur em cm: ";
cin>> tamanhoFemur;

tamanhofemur = tamanhofemur / 100.0;

int altura = tamanhoFemur / 0.032;

cout << "A altura aproximada do dinossauro " << nomeDinossauro << " é: " << altura << " metros" << endl;
return 0;
}