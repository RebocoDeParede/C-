#include <iostream>
using namespace std;

int main(){
    string nome, intensidade;
    int idade;
    float perce
}´                 