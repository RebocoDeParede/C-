#include <iostream>
using namespace std;

int main() {
    string nome;
    int idade;
    float tempo, vo2max;

    cout << "Digite o nome do atleta: ";
    cin >> nome;
    cout << "Digite a idade do atleta: ";
    cin >> idade;
    cout << "Digite o tempo corrido em minutos: ";
    cin >> tempo;

    vo2max = 483 / (tempo / 2);

    cout << "\nO VO2 máximo do atleta " << nome << " é de " << vo2max << " mL/kg/min." << endl;

    return 0;
}