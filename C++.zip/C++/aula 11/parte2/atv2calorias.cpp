#include <iostream>
using namespace std;

int main(){
    string nome, exercicio;
    float duracao, peso, calorias;

    cout<<"Digite o nome da pessoa: ";
    cin>>nome;

    cout<<"Digite o tipo de exercicio (Corrida, Natacao, Ciclismo): ";
    cin>>exercicio;

    cout<<"digite a duracao do exercicio (em minutos): ";
    cin>>duracao;

    cout<<"Digite o peso da pessoa (em KG): ";
    cin>>peso;

    if(exercicio=="Corrida"){
        calorias=duracao*0.01*peso;
    } else if (exercicio=="Natacao"){
        calorias=duracao*0.03*peso;
    } else if (exercicio=="Ciclismo"){
        calorias=duracao*0.05*peso;
    } else {
        cout<<"Exercício invalido!"<<endl;
        return 0;
    }
    cout<<"A pessoa "<<nome<<" gastou aproximadamente "<<calorias<<" calorias."<<endl;
    return 0; 
}
