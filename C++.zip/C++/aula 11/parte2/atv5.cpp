#include <iostream>
using namespace std;

int main() {
    string nome;
    int idade;
    float fc_max, aerobica_min, aerobica_max, anaerobica_min, anaerobica_max;

    cout << "Digite o seu nome: ";
    cin >> nome;
    
    cout << "Digite a idade da pessoa: ";
    cin >> idade;

    fc_max = 220 - idade;

    aerobica_min = fc_max * 0.7;
    aerobica_max = fc_max * 0.8;
    
    anaerobica_min = fc_max * 0.8;
    anaerobica_max = fc_max * 0.9;

    cout << "\n\nZona de queima de gordura: " << aerobica_min << " < x < " << aerobica_max << " bpm." << endl;
    cout << "\nZona aeróbica: " << aerobica_min << " < x < " << aerobica_max << " bpm." << endl; 
    cout << "Zona anaeróbica: " << anaerobica_min << " < x < " << anaerobica_max << " bpm." << endl; 

    return 0; 
}
