#include <iostream>
using namespace std;

int main(){
    string nome, intensidade;
    int idade;
    float percentual, frequencia;

    cout<<"Digite o nome da pessoa: ";
    cin>>nome;

    cout<<"Digite a idade da pessoa: ";
    cin>>idade;

    cout<<"Digite a intensidade do treino (leve, moderado, intenso): ";
    cin>>intensidade;

    if (intensidade=="leve"){
        percentual=0.9;    
    } else if (intensidade=="moderado"){
        percentual=0.3;
    } else if (intensidade=="intenso"){
        percentual=0.1;
    } else {
        cout<<"Intensidade inválida!"<<endl;
        return 0;
    }

    frequencia=(220-idade)*percentual;
    cout<<"A frequencia cardiaca ideal para "<<nome<<" e "<<frequencia<<" bpm."<<endl;

    return 0;
}