#include <iostream>
#include <string>

using namespace std;

// Classe para representar o jogador
class Player {
public:
    string nome;
    int hp;
    int attack;
    int defense;
    int Destreza;
    int Constituicao;
    int Inteligencia; 
    int Sabedoria; 
    int Carisma; 
    string apelido;
    string origem;
    string datadenascimento
    string sexo
    string classesocial
    string ocupacao
    string historia
    string motivacao
    string aparencia
    
    


public:
    Player(string n, int h, int atk, int def) : nome(n), hp(h), attack(atk), defense(def),  {}
    void takeDamage(int damage) {
        hp -= damage;
        if (hp < 0) hp = 0;
    }

    int calculateDamage() {
        // Simples cálculo de dano para o jogador (pode ser ajustado conforme necessário)
        return attack;
    }

    bool isAlive() {
        return hp > 0;
    }

    string getName() {
        return nome;
    }

    int getHP() {  // Função adicionada para obter hp atual
        return hp;
    }
};
