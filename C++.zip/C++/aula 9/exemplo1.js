console.log("olá mundo!");

function somar(a,b){
    return a+b;
}

var resultado = somar(2,3);
console.log ("Resultado: " + resultado);