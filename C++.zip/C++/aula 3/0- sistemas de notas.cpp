#include <iostream>

int main (){
    int nota;
    std::cout<<"Insira sua nota: ";
    std::cin>>nota;
    
    
    
    if (nota==100){
        std::cout<<"Aluno perfeito!"<<std::endl;
    } else if (nota<=9&&nota>=60){
        std::cout<<"Você passou!"<<std::endl;
    } else if (nota<=59&&nota>=40){
        std::cout<<"Parabéns, você é burro e ficou de recuperação.";
    } else {
        std::cout<<"ALA O BURRO REPROVOU KKKKKKKKKK";
    }
    return 0;
}