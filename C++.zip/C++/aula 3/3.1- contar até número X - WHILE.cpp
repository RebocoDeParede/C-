#include <iostream>

int main (){
    int i=0;
    
    while (i<=1000){
        std::cout<<"Contagem: "<<i<<std::endl;
        i++;
    }
    return 0;
}