#include <iostream>

int main(){
    for (int i=0;i<10000000000; i++ ){
        std::cout<< "Contagem; " << i << std::endl;
        
    }
     return 0;
}