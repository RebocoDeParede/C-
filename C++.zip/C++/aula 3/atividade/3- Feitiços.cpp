#include <iostream>
using namespace std;
int main (){
    int feiticho;
    cout<<"Faça sua Escolha de feiticho:";
    cin>>feiticho;
    
    switch(feiticho){
        
        case 1:
        cout<<"feitiço de Fogo, ao lançar o inimigo queima ate o inferno";
        break;
        
        case 2:
        cout<<"feitiço de gelo, ele se encontra com a elza e morre";
        break;
        
    }
}