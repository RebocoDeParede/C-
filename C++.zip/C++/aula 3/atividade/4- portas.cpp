#include <iostream>
using namespace std;
  int main (){
  char misterio;
  cout <<"Vc deseja adentrar esse misterio:";
  cin >> misterio;
   
  if (misterio == 'S') {
      cout<< "Durante a entrada da camera vc encontra um tarado"<<endl;
  } else {
      cout<< "Vc e atropelado quando ta indo embora"<<endl;
  }
  return 0;
}