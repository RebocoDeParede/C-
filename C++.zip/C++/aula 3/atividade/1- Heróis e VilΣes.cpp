#include <iostream>
int main (){
    int heroi;
    std::cout<<"Escolha seu herói ou vilão: Batman (1), Mulher Maravilha (2); Superman (3) e Capitão Vermelho (4): ";
    std::cin>>heroi;
    
    switch(heroi){
        case 1:
        
        std::cout<<"Você escolheu o herói Batman, ele é brabo e é rico, viva o capitalismo!";
        break;
        
        case 2:
        std::cout<<"Você escolheu o herói Superman, ele é o símbolo do bem e dos Estados Unidos";
        break;
        
        case 3:
        std::cout<<"Você escolheu a herói Mulher Maravilha, ela é poderosa e não deixa os vilões descansarem";
        break;
        
        case 4:
        std::cout<<"Você escolheu o vilão Capitão Vermelho, ele é o símbolo do comunismo e suas pervesidades";
        break;
        
        defalt:
        std::cout<<"Você não selecionou ninguém";
        break;
    }
    return 0;
}