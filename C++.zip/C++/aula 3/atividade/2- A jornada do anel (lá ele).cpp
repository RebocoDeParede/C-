#include <iostream>
int main (){
    int caminho;
    std::cout<<"Sua jornada para destruir o anel começa... escolha sabiamente um dos caminhos para que você possa avançar na sua jornada: Montanhas do Caos (1) ou Campos das larvas (2): ";
    std::cin>>caminho;
    
    switch(caminho){
        
        case 1:
        std::cout<<"Montanhas do caos... terremotos, monstros e pessoas infelizes te aguardam em sua jornada... ah, e não se esqueça do clima bem agradável de -63 graus, boa sorte!";
        break;
        
        case 2:
        std::cout<<"Campos das larvas... um local terrível, onde só há desespero e nojo, demônios de todos os tamanhos habitam por lá, e quase me esqueci, la existem larvas do tamanho de casas, boa sorte!";
        break;
        
    }
}