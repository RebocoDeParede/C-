#include <iostream>
using namespace std;

int main() {
    int escolha;
    
    cout << "Bem-vindo ao Labirinto Enigmático!" << endl;
    cout << "Escolha o nível de dificuldade:" << endl;
    cout << "1  Fácil" << endl;
    cout << "2  Médio" << endl;
    cout << "3  Difícil" << endl;
    cout << "4  Muito Difícil" << endl;
    cout << "5  Extremamente Difícil" << endl;
    cout << "Digite o número correspondente ao nível: ";
    cin >> escolha;
    
    if (escolha == 1) {
        cout << "Você escolheu o nível Fácil." << endl;
        cout << "Parabéns Você encontrou uma chave para a próxima sala." << endl;
        cout << "A saída está próxima" << endl;
    } else if (escolha == 2) {
        cout << "Você escolheu o nível Médio." << endl;
        cout << "Cuidado Você encontrou um monstro, mas conseguiu derrotá-lo." << endl;
        cout << "Continue avançando para encontrar a saída." << endl;
    } else if (escolha == 3) {
        cout << "Você escolheu o nível Difícil." << endl;
        cout << "Este nível é traiçoeiro. Você encontrou um beco sem saída." << endl;
        cout << "Procure outro caminho" << endl;
    } else if (escolha == 4) {
        cout << "Você escolheu o nível Muito Difícil." << endl;
        cout << "Uau, este labirinto é desafiador Você está perdido." << endl;
        cout << "Tente encontrar uma pista para a saída." << endl;
    } else if (escolha == 5) {
        cout << "Você escolheu o nível Extremamente Difícil." << endl;
        cout << "Você está encurralado por armadilhas Parece que não há saída..." << endl;
        cout << "Game Over" << endl;}
 
 return 0;

}