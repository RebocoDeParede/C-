#include <iostream>

int main (){
    int i=0;
 do{
     std::cout<<"Contagem: "<<i<<std::endl;
     i++;
 } while (i<=1000);
 return 0;
}