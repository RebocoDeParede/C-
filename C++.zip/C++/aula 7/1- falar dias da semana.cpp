#include <iostream>

using namespace std;

int main (){

string nome, codinome, origem, nascimento, sexo, classesocial, ocupacao, historia, motivacao, aparencia, atributos, habilidades;

cout<<"Seja muito bem-vindo ao criador de personagens ===Neotropolis==="<<end;


    int dia;
    cout<<"Digite o número do dia da semana (1 - 7): ";
    cin>>dia;
    
    switch(dia){
        case 1:
        cout<<"Domingo"<<endl;
        break;
        
        case 2:
    cout<<"segunda-Feira"<<endl;
    break;
    
    case 3:
    cout<<"Terça-Feira"<<endl;
    break;
    
    case 4:
    cout<<"Quarta-Feira"<<endl;
    break;
    
    case 5:
    cout<<"Quinta-Feira"<<endl;
    break;
    
    case 6:
    cout<<"Sexta-Feira"<<endl;
    break;
    
    case 7:
    cout<<"Sábado"<<endl;
    break;
    
    defalt:
    cout<<"Dia inválido"<<endl;
    break;
    }
    return 0;
}