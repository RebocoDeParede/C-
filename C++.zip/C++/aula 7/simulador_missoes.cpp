#include <iostream>
#include <vector>
#include <string>
#include <cstdlib>
#include <ctime>

using namespace std;

//Void: Void especifica que a função não retorna um valor. Quando usado para a lista de parâmetros de uma função, um item nulo especifica void que a função não usa parâmetros.
//Struct: define um tipo de estrutura e/ou uma variável de um tipo de estrutura, A ideia de usar uma struct é permitir que, ao armazenar os dados de uma mesma entidade, isto possa ser feito com uma única variável.
//Private: A única classe que tem acesso ao atributo é a própria classe que o define, ou seja, se uma classe Pessoa declara um atributo privado chamado nome, somente a classe Pessoa terá acesso a ele.
// Estrutura para atributos do personagem
struct Atributos {
    int FOR; // Força
    int DES; // Destreza do personagem
    int CON; // Constituicao
    int INT; // Inteligencia
    int SAB; // Sabedoria
    int CAR; // Carisma
};

// Estrutura para habilidades do personagem
struct Habilidades {
    int ArmasDeFogo;
    int ArmasBrancas;
    int Atletismo;
    
};

// Classe dos personagens
class Personagem {
private:
    string nome;
    string codinome;
    string origem;
    string dataNascimento;
    string sexo;
    string classeSocial;
    string ocupacao;
    string historia;
    string motivacao;
    string aparencia;
    Atributos atributos;
    Habilidades habilidades;

public:
    // Construtor
    Personagem(string n, string c, string o, string d, string s,
               string cl, string oc, string hi, string mo, string ap,
               Atributos at, Habilidades ha)
        : nome(n), codinome(c), origem(o), dataNascimento(d), sexo(s),
          classeSocial(cl), ocupacao(oc), historia(hi), motivacao(mo), aparencia(ap),
          atributos(at), habilidades(ha) {}

    // Exibe informações do personagem 
    void exibirInformacoes() const {
        cout << "Nome: " << nome << "\n";
        cout << "Codinome: " << codinome << "\n";
        cout << "Origem: " << origem << "\n";
        cout << "Data de Nascimento: " << dataNascimento << "\n";
        cout << "Sexo: " << sexo << "\n";
        cout << "Classe Social: " << classeSocial << "\n";
        cout << "Ocupacao: " << ocupacao << "\n";
        cout << "Historia: " << historia << "\n";
        cout << "Motivacao: " << motivacao << "\n";
        cout << "Aparencia: " << aparencia << "\n";
        cout << "Atributos: Força(" << atributos.FOR << ") Destrezas(" << atributos.DES << ") Constituição(" << atributos.CON << ") Inteligência(" << atributos.INT << ") Sabedoria(" << atributos.SAB << ") Carisma(" << atributos.CAR << ")\n";
        cout << "Habilidades: Armas de Fogo(" << habilidades.ArmasDeFogo << ") Armas Brancas(" << habilidades.ArmasBrancas << ") Atletismo(" << habilidades.Atletismo << ")\n";
    }

    // Getters
    const Atributos& getAtributos() const { return atributos; }
    const Habilidades& getHabilidades() const { return habilidades; }
};

// Classe das missoes
class Missao {
private:
    string nomeMissao;
    int dificuldade;
    double recompensa;
    string descricao;

public:
    //Construtor
    Missao(string n, int d, double r, string des)
        : nomeMissao(n), dificuldade(d), recompensa(r), descricao(des) {}

    //detalhes da missao
    void exibirDetalhes() const {
        cout << "Nome da Missao: " << nomeMissao << "\n";
        cout << "Dificuldade: " << dificuldade << "\n";
        cout << "Recompensa: " << recompensa << "\n";
        cout << "Descricao: " << descricao << "\n";
    }

    // Executa a missao e retorna se foi bem sucedida
    bool executarMissao(const Personagem& personagem) const {
        int chanceSucesso = personagem.getAtributos().FOR + personagem.getHabilidades().Atletismo - dificuldade;
        return chanceSucesso > 0;
    }

    // Getters
    string getNomeMissao() const { return nomeMissao; }
    double getRecompensa() const { return recompensa; }
};

// Classe que gerencia o simulador
class Simulador {
private:
    vector<Personagem> personagens;
    vector<Missao> missoes;

public:
    // Adiciona novo personagem
    void adicionarPersonagem(const Personagem& p) {
        personagens.push_back(p);
    }

    // Adiciona nova missão
    void adicionarMissao(const Missao& m) {
        missoes.push_back(m);
    }

    // Executa uma missao para um personagem
    void executarMissao(int indicePersonagem, int indiceMissao) {
        if (indicePersonagem < 0 || indicePersonagem >= personagens.size() || indiceMissao < 0 || indiceMissao >= missoes.size()) {
            cout << "Índice de personagem ou missão inválido.\n";
            return;
        }
        const Personagem& p = personagens[indicePersonagem];
        const Missao& m = missoes[indiceMissao];
        bool sucesso = m.executarMissao(p);
        if (sucesso) {
            cout << "Missão " << m.getNomeMissao() << " concluída com sucesso! Recompensa: " << m.getRecompensa() << "\n";
        } else {
            cout << "Missão " << m.getNomeMissao() << " falhou.\n";
        }
    }

    // Exibe informacoes sobre os personagens
    void exibirPersonagens() const {
        for (const auto& p : personagens) {
            p.exibirInformacoes();
            cout << "-------------------\n";
        }
    }

    // Mostra informacoes sobre missoes
    void exibirMissoes() const {
        for (const auto& m : missoes) {
            m.exibirDetalhes();
            cout << "-------------------\n";
        }
    }
};

// Funcao principal
int main() {
    Simulador simulador;

    // Adiciona alguns personagens e missoes para testes
    Atributos atributos1 = {10, 12, 14, 16, 18, 20};
    Habilidades habilidades1 = {5, 7, 9};
    Personagem p1("John Doe", "Shadow", "Neo City", "2000-01-01", "M", "Nobre", "Mercenário", "Um passado sombrio", "Procurar redenção", "Cabelos negros, olhos verdes", atributos1, habilidades1);

    Atributos atributos2 = {8, 14, 12, 15, 17, 19};
    Habilidades habilidades2 = {8, 6, 11};
    Personagem p2("Jane Smith", "Spectre", "Neo City", "1995-05-15", "F", "Média", "Espiã", "Missão secreta", "Desvendar conspirações", "Cabelos loiros, olhos azuis", atributos2, habilidades2);

    simulador.adicionarPersonagem(p1);
    simulador.adicionarPersonagem(p2);

    Missao m1("Recuperar Dados", 10, 1500.0, "Recupere dados secretos do laboratório.");
    Missao m2("Resgatar Reféns", 15, 3000.0, "Resgate os reféns da prisão.");
    
    simulador.adicionarMissao(m1);
    simulador.adicionarMissao(m2);

    // Menu principal
    int escolha;
    do {
        cout << "Menu:\n";
        cout << "1. Adicionar Personagem\n";
        cout << "2. Adicionar Missão\n";
        cout << "3. Executar Missão\n";
        cout << "4. Exibir Personagens\n";
        cout << "5. Exibir Missões\n";
        cout << "6. Sair\n";
        cout << "Escolha: ";
        cin >> escolha;
        switch (escolha) {
            case 1: {
                // Adicionar personagem
                string nome, codinome, origem, dataNascimento, sexo, classeSocial, ocupacao, historia, motivacao, aparencia;
                cout << "Nome: "; cin.ignore(); getline(cin, nome);
                cout << "Codinome: "; getline(cin, codinome);
                cout << "Origem: "; getline(cin, origem);
                cout << "Data de Nascimento: "; getline(cin, dataNascimento);
                cout << "Sexo: "; getline(cin, sexo);
                cout << "Classe Social: "; getline(cin, classeSocial);
                cout << "Ocupacao: "; getline(cin, ocupacao);
                cout << "Historia: "; getline(cin, historia);
                cout << "Motivacao: "; getline(cin, motivacao);
                cout << "Aparencia: "; getline(cin, aparencia);
                
                Atributos at;
                cout << "Força: "; cin >> at.FOR;
                cout << "Destrezas: "; cin >> at.DES;
                cout << "Constituição: "; cin >> at.CON;
                cout << "Inteligência: "; cin >> at.INT;
                cout << "Sabedoria: "; cin >> at.SAB;
                cout << "Carisma: "; cin >> at.CAR;
                
                Habilidades ha;
                cout << "Armas de Fogo: "; cin >> ha.ArmasDeFogo;
                cout << "Armas Brancas: "; cin >> ha.ArmasBrancas;
                cout << "Atletismo: "; cin >> ha.Atletismo;

                Personagem novoPersonagem(nome, codinome, origem, dataNascimento, sexo, classeSocial, ocupacao, historia, motivacao, aparencia, at, ha);
                simulador.adicionarPersonagem(novoPersonagem);
                break;
            }
            case 2: {
                // Adicionar missao
                string nomeMissao, descricao;
                int dificuldade;
                double recompensa;
                
                cout << "Nome da Missao: "; cin.ignore(); getline(cin, nomeMissao);
                cout << "Dificuldade: "; cin >> dificuldade;
                cout << "Recompensa: "; cin >> recompensa;
                cout << "Descricao: "; cin.ignore(); getline(cin, descricao);
                
                Missao novaMissao(nomeMissao, dificuldade, recompensa, descricao);
                simulador.adicionarMissao(novaMissao);
                break;
            }
            case 3: {
                // Executar missao
                int indicePersonagem, indiceMissao;
                cout << "Índice do Personagem: "; cin >> indicePersonagem;
                cout << "Índice da Missão: "; cin >> indiceMissao;
                simulador.executarMissao(indicePersonagem, indiceMissao);
                break;
            }
            case 4:
                // Exibir personagens
                simulador.exibirPersonagens();
                break;
            case 5:
                // Mostrar missões
                simulador.exibirMissoes();
                break;
            case 6:
                cout << "Saindo...\n";
                break;
            default:
                cout << "Escolha inválida. Tente novamente.\n";
                break;
        }
    } while (escolha != 6);

    return 0;
}
// tudo isso aqui pq o prof achou q a gente roubou um code da internet, sendo q ele viu a gente fazendo o codigo.... é foda.