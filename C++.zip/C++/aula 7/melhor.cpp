#include <iostream> //bibliotecas p o funcionamento do código.
#include <string>
using namespace std; //utilizado p economizar tempo e espaço na criacao do código.

//Alunos que criaram o código: Paulo Vinícius, Yago Claudino e Pedro Antônio.

 int main (){

   //string é usada p definir as características do personagem.
    string nome, apelido, origem, nascimento, sexo, classesocial, ocupacao, historia, motivacao, aparencia, destreza, saude, inteligencia, sabedoria, carisma, armasdefogo, armasbrancas, atletismo, furtividade, infiltracao, luta, medicina, persuasao, tecnologia, conducao, etiqueta, idiomas, implante, implantelocal, implantefaz, implantepreco, armas, armadura, equipamentos, creditos, reputacao, gangue, contatos;
    
    
    //msg de boas vindas ao criador de personagens.
    //o comando "\033[1m" e "\033[0m" é usado para deixar a mesagem em negrito.
    cout<<"\033[1mSeja muito bem-vindo(a) ao criador de personagens de RGP CyberPunk\033[0m"<<endl; 

cout<<"\n\033[1mVamos comecar com as caracteristicas de seu personagem:\033[0m"<<endl;



//comando "cout" utilizado p/ o programa dizer algo p/ o jogador.
//comando "getline" utilizado p/ dar ao usuário onde escrever o comano requerido.
//o comando "\n" pula uma linha.

//dados do personagem:
     cout << "\nQual o seria seu nome nesse mundo apocaliptico? ";
    getline (cin,nome);

     cout << "\nComo todo bom personagem, ele possui um apelido, qual seria o seu? ";
    getline (cin,apelido);

     cout << "\nUma pergunta meio pessoal, mas qual e origem desse incrivel(ou nao) personagem? ";
    getline (cin,origem);

     cout << "\nQual a data de nascimento de seu personagem? ";
    getline (cin,nascimento);

    cout << "\nQual o genero de seu personagem(o resultado do sexo)? ";
    getline (cin,sexo);

    cout << "\nVoce nasceu de mao beijada ou sofreu mais que guts, qual sua classe social? ";
    getline (cin,classesocial);

    cout << "\nOque voce faz na vida bb? ";
    getline (cin,ocupacao);

    cout << "\nQUAL E A INCRIVEL HISTORIA DO SEU PERSONAGEM NESSE MUNDO CAOTICO DE CYBERPUNK? ";      
    getline (cin,historia);

    cout << "\nVoce tem alguma motivacao? Caso nao tenha, voce e bem sem graca ";
    getline (cin,motivacao);

    cout << "\nQual a aparencia de seu personagem? ";
    getline (cin,aparencia);

    
    

    //atributos do personagem:
    cout << "\n\033[1mAgora vamos escolher seus ATRIBUTOS: \033[0m"<<endl;
   
    cout << "\nentre 0 e 10, quantos pontos de habilidade seu personagem tem em destreza? ";
    getline (cin,destreza);

    cout << "\nentre 0 e 10, quantos pontos de habilidade seu personagem tem em resistencia e saude? ";
    getline (cin,saude);

    cout << "\nentre 0 e 10, quantos pontos de habilidade seu personagem tem em inteligencia? ";
    getline (cin,inteligencia);

    cout << "\nentre 0 e 10, quantos pontos de habilidade seu personagem tem em sabedoria? ";
    getline (cin,sabedoria);

    cout << "\nentre 0 e 10, quantos pontos de habilidade seu personagem tem em carisma? ";
    getline (cin,carisma);




    //habilidades do personagem:
    cout<<"\033[1mDiga as HABILIDADES que seu personagem tem: \033[0m"<<endl;

    cout << "\nentre 0 e 10, quantos pontos de habilidade seu personagem tem em armas de fogo?\n ";
    getline (cin,armasdefogo);

    cout << "\nentre 0 e 10, quantos pontos de habilidade seu personagem tem em armas brancas? ";
    getline (cin,armasbrancas);

    cout << "\nentre 0 e 10, quantos pontos de habilidade seu personagem tem em atletismo? ";
    getline (cin,atletismo);

    cout << "\nentre 0 e 10, quantos pontos de habilidade seu personagem tem em furtividade? ";
    getline (cin,furtividade);

    cout << "\nentre 0 e 10, quantos pontos de habilidade seu personagem tem em infiltracao? ";
    getline (cin,infiltracao);

    cout << "\nentre 0 e 10, quantos pontos de habilidade seu personagem tem em luta? ";
    getline (cin,luta);

    cout << "\nentre 0 e 10, quantos pontos de habilidade seu personagem tem em medicina? ";
    getline (cin,medicina);

    cout << "\nentre 0 e 10, quantos pontos de habilidade seu personagem tem em persuasao? ";
    getline (cin,persuasao);

    cout << "\nentre 0 e 10, quantos pontos de habilidade seu personagem tem em tecnologia? ";
    getline (cin,tecnologia);

    cout << "\nentre 0 e 10, quantos pontos de habilidade seu personagem tem em conducao de veiculos? ";
    getline (cin,conducao);

    cout << "\nentre 0 e 10, quantos pontos de habilidade seu personagem tem em etiqueta? ";
    getline (cin,etiqueta);

    cout << "\nentre 0 e 10, quantos pontos de habilidade seu personagem tem em idiomas? ";
    getline (cin,idiomas);




    //implantes cibernético:
    cout<<"\n\033[1mDiga quais sao os IMPLANTES CIBERNETICOS de seu personagem:\033[0m"<<endl;

    cout<<"\nQual implante cibernetico seu personagem tem? (apenas um): ";
    getline(cin,implante);

    cout<<"\nOnde o implante foi istalado?";
    getline(cin,implantelocal);

    cout<<"\nO que o implante faz? ";
    getline(cin,implantefaz);

    cout<<"\nQuanto custou o implante em creditos imperiais? (dinheiro) ";
    getline(cin,implantepreco);



    //equipamentos:
    cout<<"\n\033[1mQuais equipamentos seu personagem carrega \033[0m"<<endl;

    cout<<"\nDiga as armas que voce possui: ";
    getline(cin,armas);

    cout<<"\nDiga as armadura que voce possui: ";
    getline(cin,armadura);

    cout<<"\nDiga os equipamentos que voce tem: ";
    getline(cin,equipamentos);



    //dinheiro:
    cout<<"\nQuantos creditos imperiais voce tem? (dinheiro) ";
    getline(cin,creditos);

    

    //outras info:
    cout<<"\nDiga como e sua reputacao no meio do povo: ";
    getline(cin,reputacao);

    cout<<"\nVoce faz parte de alguma gangue? ";
    getline(cin,gangue);

    cout<<"\nVoce tem contato com alguem importante? se sim, quem? ";
    getline(cin,contatos);


    
    //a partir desta parte, o programa mostra ao usuário as característcas do personagem criado.
    cout<<"\n\033[1mINFORMACOES DO PERSONAGEM:\033[0m\n"<<endl;


//info do personagem:
    cout<<"\n--INFORMACOES GERAIS--\n";
    cout <<"Nome: " << nome << "\n";
    cout <<"Apelido: " << apelido << "\n";
    cout <<"Origem: " << origem << "\n";
    cout <<"Data de nascimento: " << nascimento << "\n";
    cout <<"Sexo do personagem: " << sexo << "\n";
    cout <<"Classe social: " << classesocial << "\n";
    cout <<"Ocupacao: " << ocupacao << "\n";
    cout <<"Historia: " << historia << "\n";
    cout <<"Motivacao: " << motivacao << "\n";
    cout <<"Aparencia: " << aparencia << "\n";
    cout <<"Reputacao: " << reputacao << "\n";
    cout <<"Gangue: " << gangue << "\n";
    cout <<"Contatos: " << contatos << "\n";


//atributos do personagem:
    cout<<"\n--ATRIBUTOS--\n";
    cout <<"Destreza: " << destreza << "\n";
    cout <<"Saude: " << saude << "\n";
    cout <<"Inteligencia: " << inteligencia << "\n";
    cout <<"Sabedoria: " << sabedoria << "\n";
    cout <<"Carisma: " << carisma << "\n";
    

//habilidades do personagem:
    cout<<"\n--HABILIDADES--\n";
    cout <<"armas de fogo: " << armasdefogo << "\n";
    cout <<"armas brancas: " << armasbrancas << "\n";
    cout <<"atletismo: " << atletismo << "\n";
    cout <<"furtividade: " << furtividade << "\n";
    cout <<"infiltracao: " << infiltracao << "\n";
    cout <<"luta: " << luta << "\n";
    cout <<"medicina: " << medicina << "\n";
    cout <<"persuasao: " << persuasao << "\n";
    cout <<"tecnologia: " << tecnologia << "\n";
    cout <<"conducao: " << conducao << "\n";
    cout <<"etiqueta: " << etiqueta << "\n";
    cout <<"idiomas: " << idiomas << "\n";
    
    
    //implantes cibernéticos:
    cout<<"\n--IMPLANTES CIBERNETICOS--\n";
    cout <<"Implante: " << implante << "\n";
    cout <<"Local do implante cyber: " << implantelocal << "\n";
    cout <<"Funcao do implante: " << implantefaz << "\n";
    cout <<"Preco do implante: " << implantepreco << "\n";
    

   //equipamentos:
    cout<<"\n--SEUS EQUIPAMENTOS--\n";
    cout <<"Armas: " << armas << "\n";
    cout <<"Armadura: " << armadura << "\n";
    cout <<"Equipamentos: " << equipamentos << "\n";
    
    
    //dinheiro
    cout<<"\n--FINANCAS--\n";
    cout <<"Creditos imperiais: " << creditos << "\n";

    return 0; //aqui o código termina, encerrando o programa.
 }
