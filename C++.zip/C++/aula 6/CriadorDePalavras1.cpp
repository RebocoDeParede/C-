#include <iostream>
using namespace std;

int main(){
    int tamanhoMaximoVetor=100;
    int corDaCamisa, diaDoAniversario, mesDoAniversario;
    string resultadoCorDaCamisa, resultadoDiaDoAniversario, resultadoMesDoAniversario;

    string corCamisa[tamanhoMaximoVetor] = {
        "Preto",
        "Branco",
        "Vermelho",
        "Azul",
        "Verde",
        "Amarelo",
        "Roxo",
        "Cinza",
        "Marrom",
        "Laranja"};

    string corVetor[tamanhoMaximoVetor] = {
 "O Harry Potter",
 "A Hermione Granger",
 "O Goku",
 "A Sailor Moon",
 "O Bruce Wayne",
 "A Daenerys Targaryen",
 "O Lionel Messi",
 "A Marta",
 "O Cristiano Ronaldo",
 "A Alex Moran"};

string diaVetor[tamanhoMaximoVetor] = {
    "Armadura de Homem de Ferro",
        "Uniforme de Hogwarts",
        "Capa do Batman",
        "Traje do Homem-Aranha",
        "Vestido da Elsa",
        "Túnica Jedi de Star Wars",
        "Vestido da Mulher Maravilha",
        "Roupa de Superman",
        "Kimono do Goku",
        "Traje de pirata do Jack Sparrow",
        "Traje tradicional hanbok",
        "Uniforme escolar coreano",
        "Terno e gravata elegante",
        "Vestido de noiva coreano",
        "Roupa casual de um herói de dorama",
        "Uniforme militar coreano",
        "Vestido de gala em um evento de dorama",
        "Roupa de policial coreano",
        "Vestimenta de CEO de dorama",
        "Roupa de médico em hospital coreano",
        "Uniforme do Barcelona",
        "Uniforme do PSG",
        "Camisa da seleção brasileira",
        "Uniforme do Manchester United",
        "Uniforme do Real Madrid",
        "Uniforme do SENAI",
        "Camisa de treino de futebol",
        "Agasalho de futebol para aquecimento",
        "Roupa de goleiro completa",
        "Uniforme da seleção argentina",
        "Uniforme do Chelsea"};

string mesVetor[tamanhoMaximoVetor] = {
        "Karl Marx",
        "Joseph Stalin",
        "Vladimir Lenin",
        "Fidelis Reis",
        "Rainha Elizabeth I",
        "Che Guevara",
        "Albert Einstein",
        "Napoleão Bonaparte",
        "Marie Curie",
        "Yago Claudino",
        "Leno Yu Silva",
        "Gato Makonha"};

cout<<"Bem vindo(a) ao criador de frases pra aprendizado de loops e vetores!"<<endl;

cout<<"Escolha uma cor de camisa da lista abaixo: "<<endl;
for (int i=0;i<10;i++) {
    cout<<i+1<<". "<<corCamisa[i]<<endl;
}

cout<<"Digite o numero correspondente a cor de sua camisa: ";
cin>>corDaCamisa;
if (corDaCamisa>=1 && corDaCamisa<=20) {
    resultadoCorDaCamisa=corVetor[corDaCamisa -1];
} else {
    cout<<"Numero invalido para a cor da camisa. Por favor, escolha um numero entre 1 e 10."<<endl;
    return 1;
}

cout<<"Digite o dia do seu aniversario (1-31):";
cin>>diaDoAniversario;

if (diaDoAniversario >=1 && diaDoAniversario <=31)
{
    resultadoDiaDoAniversario = diaVetor[diaDoAniversario -1];
} else {
    cout<<"Numero invalido para o mes do aniversario. Por favor, escolha um numero entre 1 e 12."<<endl;
    return 1;
}

cout << "Digite o mês de seu aniversário (1-12): ";
    cin >> mesDoAniversario;

    if (mesDoAniversario >= 1 && mesDoAniversario <= 12)
    {
        resultadoMesDoAniversario = mesVetor[mesDoAniversario - 1];
    }
    else
    {
        cout << "Número inválido para o mês do aniversário. Por favor, escolha um número entre 1 e 12." << endl;
        return 1;
    }
    
cout<<"Sua frase e: "<<endl;
 cout << "Um dia encontrei " << resultadoCorDaCamisa << " vestindo " << resultadoDiaDoAniversario << " enquanto " << resultadoMesDoAniversario << " Vendia algoritmos." << endl;
 return 0;
}